exports.handler = async (event) => {
    console.log("Lambda function executed!", JSON.stringify(event, null, 2));
    return { statusCode: 200, body: "Lambda executed successfully!" };
};
